# Changelog

## [1.0.0] - Initial Release

- **Initial release! Time to get fat!**

