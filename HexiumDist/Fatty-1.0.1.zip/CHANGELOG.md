# Changelog

## [1.0.1]

- Removed diagnostic dump log information
- Better default configs

## [1.0.0] - Initial Release

- **Initial release! Time to get fat!**

