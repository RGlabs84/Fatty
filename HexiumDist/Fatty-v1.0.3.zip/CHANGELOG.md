# Changelog

## [1.0.3]

- **Fixed: Eitr no longer breaks alongside other mods.** Fatty was overwriting the game's food totals
  outright instead of adding to them, wiping out any other mod's contribution. Base Eitr from
  AllTheBases now works properly (it previously applied on an empty stomach and vanished the moment
  you ate), and FoodDurationMultiplier's health/stamina/eitr benefit settings apply again.
- **Fixed: stamina and Eitr regeneration no longer fall behind.** The game regenerates both at a flat
  rate that ignores how big your bars are, so Fatty's larger pools took far longer to refill - worst
  of all for mages. Regen now scales with the pool, keeping refill times at vanilla parity. New
  "6 - Regen" config section to tune or disable it.
- Fixed: food health regeneration now respects stack diminishing returns like every other stat,
  instead of healing at full value for every stack.
- Fixed: synergy config values were read once at startup, before a server could send its own, so
  server-synced values never actually applied.
- Fixed: Balanced Diet's regen multiplier can now be set below 1.0, as its description says.


## [1.0.2]

- Added compatibility with blacks7ar's FoodDurationMultiplier mod

## [1.0.1]

- Removed diagnostic dump log information
- Better default configs

## [1.0.0] - Initial Release

- **Initial release! Time to get fat!**

