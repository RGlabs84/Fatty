<div align="center">
  
# 🍖 FATTY: The Valheim Culinary Overhaul 🍻

*Stop surviving. Start feasting.* 

Fatty is a massive overhaul to Valheim's food system: it stops food stats from decaying, grows your food bar from 3 slots to 5 (a new **4th food slot** *and* a dedicated **5th drink slot**), lets you stack the same food for bonus stats, and rewards a varied diet with powerful synergy buffs — each with its own custom icon. Built-in compatibility with mods like `blacks7ar.FoodDurationMultiplier`.

---
</div>

## ✨ Core Features

### 🛑 No Food Decay
Hate watching your health and stamina slowly tick down to nothing? **Fatty** disables vanilla food decay. When you eat, you keep **100% of a food's stats until its timer fully expires** — no gradual fade. *(Configurable — you can turn decay back on and keep the rest of the mod.)*

### 🥞 Stat Stacking
If you really love Lox Meat, why stop at one? Fatty lets you eat the **same food multiple times** to pile on stats.
- By default you can stack a food up to **4 times**.
- To keep it balanced, extra stacks give **diminishing returns** (configurable).
- *Default:* 1st serving = 100%, 2nd = 25%, 3rd = 5%, 4th = 2%.
- The HUD shows an **"×N" badge** so you always know how many times a food is stacked.

### 🍺 A 4th Food Slot + a 5th Drink Slot
Vanilla only gives you **3** food slots. Fatty expands the food bar to **5**: a brand-new **4th solid-food slot** *plus* a dedicated **5th slot just for drinks** — so you can run 4 foods and a drink at once. Icons get a **gold trim** for a cleaner look.

> Note: the drink slot covers **every** drink — including vanilla/modded meads that just grant a timed status effect with no food stats (Frost Resistance, Tasty Mead, etc.), not only drinks that carry food stats.

### 🥗 Dietary Synergies
Eating the right combination of food categories triggers a unique, powerful **Status Effect** — complete with its own **custom icon** — applied and removed automatically as your diet changes:

| Synergy | Recipe | Effect |
| :--- | :--- | :--- |
| **🟢 Balanced Diet** | 1 Meat + 1 Veggie | Greatly increased Health & Stamina regen |
| **🩷 Sugar Rush** | 3 Sweets + 1 Drink | Big movement-speed boost |
| **🔵 Fisherman's Friend** | 2 Fish + 1 Veggie | Improved swim speed & reduced swim stamina use |
| **🟤 Lumberjack's Feast** | 3 Meat + 1 Drink | Bonus carry weight & woodcutting damage |

*Every synergy's strength is configurable, and all of them are server-synced.*

---

## 🛠️ Configuration & Data-Driven Modding

### ⚙️ ServerSync
Fatty is fully ServerSync integrated. Server admins have authority over **all gameplay values** — no-decay, max stacks, diminishing returns, and every synergy's strength. *(Only the personal debug-logging toggle stays local to each client.)*

Key options include: **No Food Decay**, **Max Food Stacks**, the three **Stack Multipliers**, and per-synergy tuning (Balanced Diet regen, Sugar Rush speed, Fisherman stamina reduction, Lumberjack carry weight & woodcutting damage).

### 🤝 Food-Mod Compatibility
Fatty is built to play nicely with **any** food mod:
- **Automatic, open support:** Fatty scans every food in the game — from the base game or *any* mod — and sorts each one into a category (Meat, Vegetable, Sweet, Fish, Drink) using its name. New foods just work.
- **Valheim Cuisine:** specifically recognized. When Valheim Cuisine is installed, Fatty detects it and pre-sorts its meats, fish, sweets, and drinks into the right categories out of the box, using Valheim Cuisine's own recipe ingredients as ground truth — not just guessing from the name.
- **Full manual control:** anything the auto-sorter gets wrong, you fix in one JSON file (below).

### 📁 The JSON Data File
The **first** time you run Fatty, it writes every food's real stats and category to `BepInEx/config/Fatty_FoodData.json`. After that it **only rewrites the file when it discovers new foods** (for example, after you add another food mod) — so a normal launch never touches it and **your manual edits are preserved**.

**Want to change a food's category?** Just edit that JSON file — set any food to Meat, Drink, Veggie, Sweet, or Fish, and Fatty will respect it.

---

## 🧩 Dependencies
Fatty needs just two things at runtime (a mod manager like **r2modman** / **Thunderstore Mod Manager** installs them automatically):

| Dependency | Why |
| :--- | :--- |
| **[BepInExPack Valheim](https://valheim.thunderstore.io/package/denikson/BepInExPack_Valheim/)** | The mod loader (also provides HarmonyX). |
| **[JsonDotNET](https://valheim.thunderstore.io/package/ValheimModding/JsonDotNET/)** | Newtonsoft.Json, used to read/write `Fatty_FoodData.json`. |

*(ServerSync is compiled into Fatty and needs no separate download.)*

## 📥 Installation
**With a mod manager (recommended):** just install Fatty — the dependencies above are pulled in for you.

**Manual install:**
1. Install **BepInExPack Valheim** and **JsonDotNET**.
2. Drop `Fatty.dll` into `BepInEx/plugins`.
3. Eat up! 

<div align="center">
  <i>Created with ❤️ by Wubarrk</i>
</div>
